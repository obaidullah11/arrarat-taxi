from django.shortcuts import render
from django.db.models import Sum
from django.db.models.functions import TruncDate
from rest_framework import status
from django.conf import settings
from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework.generics import ListAPIView, UpdateAPIView
from .serializers import *

# Create your views here.
class AssignPassengerByDriversignaturesheetAPIView(ListAPIView):
    serializer_class = AssignPassengerTosignaturesheet1Serializer

    def get_queryset(self):
        # Get the driver_id from the URL parameter
        driver_id = self.kwargs['driver_id']

        # Filter the queryset to retrieve passenger assignments for the given driver_id
        queryset = AssignPassengerTosignature_sheet1.objects.filter(user_id=driver_id)

        return queryset
    


@api_view(['POST'])
def add_signature_sheet(request):
    if request.method == 'POST':
        serializer = SignatureSheetSerializer(data=request.data)

        if serializer.is_valid():
            serializer.save()
            message = "Record created successfully."
            return Response({"message": message, "data": serializer.data}, status=status.HTTP_201_CREATED)
        
        errors = serializer.errors
        return Response({"errors": errors}, status=status.HTTP_400_BAD_REQUEST)
    



@api_view(['GET'])
def get_driver_records1(request, driver_id):
    runsheets = signature_sheet1.objects.filter(driver__id=driver_id)

    if not runsheets.exists():
        return Response(status=status.HTTP_404_NOT_FOUND)

    runsheets = runsheets.annotate(date=TruncDate('date_created')).order_by('date')
    runsheet_array = []
    total_morning_all = 0
    total_evening_all = 0
    grouped_runsheets = {}

    for runsheet in runsheets:
        date = runsheet.date
        formatted_date = date.strftime("%A %d/%m/%Y")
        passenger_name = runsheet.passenger_name.name  # Assuming name is a field in the Passenger model
        driver_name = runsheet.driver.name  # Assuming name is a field in the User model

        # Generate the URL for the signature image
        signature_url = settings.MEDIA_URL + str(runsheet.signature)

        runsheet_data = {
            'id': runsheet.id,  # Include the runsheet ID
            'passenger_name': passenger_name,
            'formatted_date_created': formatted_date,
            'Morning_price': runsheet.Morning_price,
            'Evening_price': runsheet.Evening_price,
            'driver': driver_name,
            'signature': request.build_absolute_uri(signature_url),  # Include the signature URL
        }

        if formatted_date in grouped_runsheets:
            grouped_runsheets[formatted_date]['runsheets'].append(runsheet_data)
            grouped_runsheets[formatted_date]['total_morning_price'] += runsheet.Morning_price if runsheet.Morning_price is not None else 0
            grouped_runsheets[formatted_date]['total_evening_price'] += runsheet.Evening_price if runsheet.Evening_price is not None else 0
        else:
            grouped_runsheets[formatted_date] = {
                'formatted_date_created': formatted_date,
                'runsheets': [runsheet_data],
                'total_morning_price': runsheet.Morning_price if runsheet.Morning_price is not None else 0,
                'total_evening_price': runsheet.Evening_price if runsheet.Evening_price is not None else 0,
            }

        total_morning_all += runsheet.Morning_price if runsheet.Morning_price is not None else 0
        total_evening_all += runsheet.Evening_price if runsheet.Evening_price is not None else 0

    for date_key in grouped_runsheets:
        runsheet_array.append(grouped_runsheets[date_key])

    # Add overall totals to the response data
    response_data = {
        'grouped_runsheets': runsheet_array,
        'total_morning_all': total_morning_all,
        'total_evening_all': total_evening_all,
    }

    return Response(response_data)