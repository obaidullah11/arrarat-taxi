from rest_framework import serializers
from .models import *


class AssignPassengerTosignaturesheet1Serializer(serializers.ModelSerializer):
    # Add the passenger name field to the serializer
    passenger_name = serializers.ReadOnlyField(source='passenger.name')

    class Meta:
        model = AssignPassengerTosignature_sheet1
        fields = ['id', 'user', 'passenger', 'date_created', 'passenger_name']



class SignatureSheetSerializer(serializers.ModelSerializer):
    class Meta:
        model = signature_sheet1
        fields = '__all__'