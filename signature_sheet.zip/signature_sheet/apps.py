from django.apps import AppConfig


class SignatureSheetConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'signature_sheet'
